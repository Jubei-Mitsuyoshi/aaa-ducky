1.5.0-QUACK / 2013-06-23 
========================

  * added to .gitignore
  * Merge branch 'master' of github.com:gitdurandal/dbd
  * added ppc64 dbd statically compiled with dietlibc
  * Merge pull request #1 from gitbrew/master
  * updated email address
  * added arm binary statically cross compiled with dietlibc
  * ugly Makefile fix for better crossbuild support
  * added 32-bit linux dbd compiled statically with dietlibc
  * added .gitignore
  * whoops...
  * fixed comment... finally
  * Merge pull request #4 from gitdurandal/master
  * added static ppc64 dbd for ps3 test
  * Merge pull request #3 from gitdurandal/master
  * updated arm and arm64 binaries
  * updated linux and win32 binaries
  * Fixed version
  * Merge pull request #2 from gitdurandal/master
  * added linux32 binaries
  * added windows dbd binaries
  * Merge pull request #1 from gitdurandal/master
  * Updated copyright and version info
  * made dbd crossbuild friendly
  * removed old binaries
  * minor changes
1.2.0 / 2012-04-18
==================

  * 1.2.0 release
  * Will try to find nice way to cross build for android without needing full sdk/ndk/wtfk
  * minor edit to mingw*-cross options
  * added win32 cross compile options
  * added arm-cross
  * changed README
  * updated readme
  * fixed Makefile Unix32
  * added 32-bit *nix option to Makefile
  * Merge branch 'master' of github.com:gitdurandal/dbd
  * changed readme
  * added make dist
  * purtied it up
  * fixed
  * made Makefile more verbose
  * fixed preamble
  * added upx-packed win32 exes
  * added win32 stealth (no output) exe
  * edited dbd.h
  * edited preambles
  * edited CHANGES
  * edited readme
  * edited readme
1.0.0 / 2012-04-05
==================

  * first commit
