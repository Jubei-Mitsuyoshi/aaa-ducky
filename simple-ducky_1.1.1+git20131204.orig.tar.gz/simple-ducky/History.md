
1.1.1 / 2013-06-22 
==================

  * updated readme to clone recursively
  * Moved dbd to a submodule and set to autoinitialize
  * Simple-Ducky Payload Generator v1.1.1
